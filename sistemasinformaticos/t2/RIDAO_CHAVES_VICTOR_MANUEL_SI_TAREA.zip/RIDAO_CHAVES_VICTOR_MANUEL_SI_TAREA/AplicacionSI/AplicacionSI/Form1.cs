using System;
using System.Linq;
using System.Management;
using System.Net;
using System.Reflection;
using System.Windows.Forms;

namespace AplicacionSI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // M�todo para obtener las unidades de discos
        private void boton1_Click(object sender, EventArgs e)
        {
            textBox1.Text = ObtenerUnidadesDiscos();
        }

        // M�todo para obtener la capacidad libre de los discos
        private void boton2_Click(object sender, EventArgs e)
        {
            textBox2.Text = ObtenerCapacidadLibreDiscos();
        }

        // M�todo para obtener el nombre del equipo
        private void boton3_Click(object sender, EventArgs e)
        {
            textBox3.Text = ObtenerNombreEquipo();
        }

        // M�todo para obtener la memoria RAM
        private void boton4_Click(object sender, EventArgs e)
        {
            textBox4.Text = ObtenerMemoriaRAM();
        }

        // M�todo para obtener las direcciones IP
        private void boton5_Click(object sender, EventArgs e)
        {
            textBox5.Text = ObtenerIPs();
        }

        // M�todo para obtener el sistema operativo
        private void boton6_Click(object sender, EventArgs e)
        {
            textBox6.Text = ObtenerSistemaOperativo();
        }

        // M�todo para obtener la tarjeta gr�fica
        private void boton7_Click(object sender, EventArgs e)
        {
            textBox7.Text = ObtenerTarjetaGrafica();
        }

        // M�todo para obtener la temperatura del equipo
        private void boton8_Click(object sender, EventArgs e)
        {
            textBox8.Text = ObtenerTemperatura();
        }

        // Obtener las unidades de discos
        private string ObtenerUnidadesDiscos()
        {
            string[] unidades = Environment.GetLogicalDrives(); 
            string resultado = "Unidades de disco:\n";

            foreach (string unidad in unidades)
            {
                resultado += $"{unidad}\n"; 
            }

            return resultado;
        }

        // Obtener la capacidad libre de los discos
        private string ObtenerCapacidadLibreDiscos()
        {
            string capacidades = "";
            var query = new ManagementObjectSearcher("SELECT * FROM Win32_LogicalDisk WHERE DriveType=3");
            foreach (var obj in query.Get())
            {
                long capacidadLibre = Convert.ToInt64(obj["FreeSpace"]) / (1024 * 1024 * 1024);
                capacidades += $"{obj["DeviceID"]}: {capacidadLibre} GB libres{Environment.NewLine}";
            }
            return capacidades;
        }

        // Obtener nombre del equipo
        private string ObtenerNombreEquipo()
        {
            return $"Nombre del equipo: {Environment.MachineName}";
        }

        // Obtener la memoria RAM
        private string ObtenerMemoriaRAM()
        {
            ObjectQuery objectQuery = new("SELECT * FROM Win32_OperatingSystem");

            ManagementObjectSearcher searcher = new ManagementObjectSearcher(objectQuery);

            string resultado = string.Empty;

            foreach (var queryObj in searcher.Get())
            {
                decimal memoriaTotal = Math.Round(Convert.ToDecimal(queryObj["TotalVisibleMemorySize"]) / (1024 * 1024), 2);
                decimal memoriaLibre = Math.Round(Convert.ToDecimal(queryObj["FreePhysicalMemory"]) / (1024 * 1024), 2);

                string memorialTotalMensaje = $"Memoria total es: {memoriaTotal} GB";
                string memorialLibreMensaje = $"Memoria libre es: {memoriaLibre} GB";

                resultado = memorialTotalMensaje + Environment.NewLine + memorialLibreMensaje;
            }

            return resultado;
        }

        // Obtener las direcciones IPs
        private string ObtenerIPs()
        {
            string[] ips = Dns.GetHostAddresses(Dns.GetHostName())
                              .Where(ip => !ip.IsIPv6LinkLocal)
                              .Select(ip => ip.ToString())
                              .ToArray();
            return string.Join(Environment.NewLine, ips);
        }

        // Obtener el sistema operativo
        private string ObtenerSistemaOperativo()
        {
            string arquitectura = (Environment.Is64BitOperatingSystem) ? "x64" : "x86";
            return $"Sistema Operativo: {Environment.OSVersion.VersionString}, Arquitectura: {arquitectura}";
        }

        // Obtener la tarjeta gr�fica
        private string ObtenerTarjetaGrafica()
        {
            string resultado = "";
            var query = new ManagementObjectSearcher("SELECT * FROM Win32_VideoController");
            foreach (var obj in query.Get())
            {
                resultado = $"Tarjeta Gr�fica: {obj["Caption"]}";
            }
            return resultado;
        }

        // Obtener temperatura del PC
        private string ObtenerTemperatura()
        {
            string temperatura = "No disponible";
            try
            {
                var query = new ManagementObjectSearcher("SELECT * FROM Win32_TemperatureProbe");
                foreach (var obj in query.Get())
                {
                    temperatura = $"{obj["CurrentReading"]} �C";
                }
            }
            catch
            {
                temperatura = "No se pudo obtener la temperatura.";
            }
            return temperatura;
        }
    }
}
