﻿

namespace AplicacionSI
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            fontDialog1 = new FontDialog();
            textBox1 = new TextBox();
            button1 = new Button();
            textBox2 = new TextBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            textBox5 = new TextBox();
            button6 = new Button();
            textBox6 = new TextBox();
            button7 = new Button();
            textBox7 = new TextBox();
            button8 = new Button();
            textBox8 = new TextBox();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.FromArgb(192, 0, 192);
            textBox1.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(12, 12);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(284, 73);
            textBox1.TabIndex = 2;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // button1
            // 
            button1.BackColor = Color.Gold;
            button1.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Red;
            button1.Location = new Point(53, 91);
            button1.Name = "button1";
            button1.Size = new Size(187, 29);
            button1.TabIndex = 3;
            button1.Text = "Obtener unidades";
            button1.UseVisualStyleBackColor = false;
            button1.BackgroundImageChanged += checkBox1_CheckedChanged;
            button1.Click += button1_Click_1;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.FromArgb(192, 0, 192);
            textBox2.Location = new Point(12, 149);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.ReadOnly = true;
            textBox2.Size = new Size(284, 69);
            textBox2.TabIndex = 4;
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.FromArgb(128, 255, 255);
            textBox4.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            textBox4.Location = new Point(1062, 12);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.ReadOnly = true;
            textBox4.Size = new Size(284, 73);
            textBox4.TabIndex = 5;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.FromArgb(192, 0, 192);
            textBox3.Location = new Point(12, 289);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.ReadOnly = true;
            textBox3.Size = new Size(284, 65);
            textBox3.TabIndex = 6;
            // 
            // button2
            // 
            button2.BackColor = Color.Gold;
            button2.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Red;
            button2.Location = new Point(53, 228);
            button2.Name = "button2";
            button2.Size = new Size(190, 29);
            button2.TabIndex = 7;
            button2.Text = "Capacidad unidades";
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.Gold;
            button3.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.Red;
            button3.Location = new Point(53, 360);
            button3.Name = "button3";
            button3.Size = new Size(190, 29);
            button3.TabIndex = 8;
            button3.Text = "Nombre equipo";
            button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = Color.IndianRed;
            button4.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            button4.Location = new Point(1115, 91);
            button4.Name = "button4";
            button4.Size = new Size(190, 29);
            button4.TabIndex = 9;
            button4.Text = "Direcciones IPs";
            button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            button5.BackColor = Color.IndianRed;
            button5.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            button5.Location = new Point(1115, 228);
            button5.Name = "button5";
            button5.Size = new Size(190, 29);
            button5.TabIndex = 11;
            button5.Text = "Sistema Operativo";
            button5.UseVisualStyleBackColor = false;
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.FromArgb(128, 255, 255);
            textBox5.Location = new Point(1062, 149);
            textBox5.Multiline = true;
            textBox5.Name = "textBox5";
            textBox5.ReadOnly = true;
            textBox5.Size = new Size(284, 73);
            textBox5.TabIndex = 10;
            // 
            // button6
            // 
            button6.BackColor = Color.IndianRed;
            button6.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            button6.Location = new Point(1115, 360);
            button6.Name = "button6";
            button6.Size = new Size(190, 29);
            button6.TabIndex = 13;
            button6.Text = "Tarjeta Gráfica";
            button6.UseVisualStyleBackColor = false;
            // 
            // textBox6
            // 
            textBox6.BackColor = Color.FromArgb(128, 255, 255);
            textBox6.Location = new Point(1062, 281);
            textBox6.Multiline = true;
            textBox6.Name = "textBox6";
            textBox6.ReadOnly = true;
            textBox6.Size = new Size(284, 73);
            textBox6.TabIndex = 12;
            // 
            // button7
            // 
            button7.BackColor = Color.Gold;
            button7.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            button7.ForeColor = Color.Red;
            button7.Location = new Point(65, 511);
            button7.Name = "button7";
            button7.Size = new Size(190, 29);
            button7.TabIndex = 15;
            button7.Text = "Memoria RAM";
            button7.UseVisualStyleBackColor = false;
            // 
            // textBox7
            // 
            textBox7.BackColor = Color.FromArgb(192, 0, 192);
            textBox7.Location = new Point(12, 432);
            textBox7.Multiline = true;
            textBox7.Name = "textBox7";
            textBox7.ReadOnly = true;
            textBox7.Size = new Size(284, 73);
            textBox7.TabIndex = 14;
            // 
            // button8
            // 
            button8.BackColor = Color.IndianRed;
            button8.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            button8.Location = new Point(1115, 484);
            button8.Name = "button8";
            button8.Size = new Size(190, 29);
            button8.TabIndex = 17;
            button8.Text = "Temperatura equipo";
            button8.UseVisualStyleBackColor = false;
            // 
            // textBox8
            // 
            textBox8.BackColor = Color.FromArgb(128, 255, 255);
            textBox8.Location = new Point(1062, 405);
            textBox8.Multiline = true;
            textBox8.Name = "textBox8";
            textBox8.ReadOnly = true;
            textBox8.Size = new Size(284, 73);
            textBox8.TabIndex = 16;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MidnightBlue;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            CancelButton = button1;
            ClientSize = new Size(1358, 578);
            Controls.Add(button8);
            Controls.Add(textBox8);
            Controls.Add(button7);
            Controls.Add(textBox7);
            Controls.Add(button6);
            Controls.Add(textBox6);
            Controls.Add(button5);
            Controls.Add(textBox5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(textBox3);
            Controls.Add(textBox4);
            Controls.Add(textBox2);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "Form1";
            BackgroundImageChanged += button1_Click_1;
            ResumeLayout(false);
            PerformLayout();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.Text = ObtenerUnidadesDiscos();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = ObtenerUnidadesDiscos();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }



        #endregion
        private FontDialog fontDialog1;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox7;
        private TextBox textBox8;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
    }
}
