public enum TipoDificultad {
    FACIL,
    MEDIA,
    DIFICIL
}
