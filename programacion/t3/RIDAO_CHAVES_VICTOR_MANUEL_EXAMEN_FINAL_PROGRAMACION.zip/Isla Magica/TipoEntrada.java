public enum TipoEntrada {
    INFANTIL,
    GENERAL,
    VIP
}
