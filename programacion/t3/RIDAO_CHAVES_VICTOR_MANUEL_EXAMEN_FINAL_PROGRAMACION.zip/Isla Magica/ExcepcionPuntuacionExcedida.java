public class ExcepcionPuntuacionExcedida extends Participacion {
    public ExcepcionPuntuacionExcedida(String mensaje) {
        super(mensaje);
    }
}