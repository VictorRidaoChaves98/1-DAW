public enum TipoProducto {
    BEBIDA,
    COMIDA,
    POSTRE
}
