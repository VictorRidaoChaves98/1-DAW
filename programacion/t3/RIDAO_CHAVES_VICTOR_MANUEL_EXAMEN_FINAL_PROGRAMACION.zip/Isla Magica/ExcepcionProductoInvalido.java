public class ExcepcionProductoInvalido extends Producto {
    public ExcepcionProductoInvalido(String mensaje) {
        super(mensaje, 0, null);
    }
}